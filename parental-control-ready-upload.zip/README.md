This project contains child and parent Android modules. Use Android Studio to complete and build.
